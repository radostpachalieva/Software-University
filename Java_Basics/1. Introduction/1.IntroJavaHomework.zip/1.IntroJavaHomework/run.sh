#!/bin/bash
java -jar /home/amaurea/workspace/1.IntroJavaHomework/GenPDF.jar
