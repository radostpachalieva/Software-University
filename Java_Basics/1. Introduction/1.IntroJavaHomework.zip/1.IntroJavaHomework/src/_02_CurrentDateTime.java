import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class _02_CurrentDateTime {

	public static void main(String[] args) {
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

		Date date = new Date();
		System.out.println(dateFormat.format(date)); // 2014/08/06 15:59:48

	}

}
