import java.util.Scanner;

public class _06_SumTwoNumbers {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		//System.out.print("First number = ");
		int a = input.nextInt();
		//System.out.print("Second number = ");
		int b = input.nextInt();

		System.out.println(a + b);

	}

}
