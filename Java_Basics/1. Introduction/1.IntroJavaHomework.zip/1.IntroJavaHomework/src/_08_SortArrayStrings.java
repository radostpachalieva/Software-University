import java.util.Arrays;
import java.util.Scanner;

public class _08_SortArrayStrings {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		int n = in.nextInt();
		in.nextLine();
		// int n = Integer.valueOf(in.nextLine());
		
		String[] array = new String[n];
		
		for (int i = 0; i < n; i++) {
			array[i] = in.nextLine();			
			}
		Arrays.sort(array);
		for (String v : array) {
		    System.out.println(v);
		}
	}
}