import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;

import com.itextpdf.text.Font;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Element;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class _09_GeneratePDF {
	 
    public static void main(String[] args) throws IOException {
    	
            Document document = new Document();
            
            try {
                    BaseFont baseFont = BaseFont.createFont("Arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
                    Font red = new Font(baseFont, 20, Font.BOLDITALIC, BaseColor.RED);
                    Font black = new Font(baseFont, 20, Font.BOLDITALIC, BaseColor.BLACK);
            	
                    String card = "";
                    
                    //char[] colors = new char[] {'♣','♦','♥','♠'};
                    char clubs = '♠';
                    char hearts = '♥';
                    char diamonds = '♦';                    
                    char spades = '♣';
           
                    
        PdfWriter.getInstance(document, new FileOutputStream("Cards.pdf"));

        document.open();
        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(35);
        table.getDefaultCell().setFixedHeight(55);
        table.getDefaultCell().setBorderColor(BaseColor.DARK_GRAY);
        table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
        table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
        table.getDefaultCell().setLeading(15f, 0f);
       
        for(int i = 2; i <=14; i++){
            switch(i){
                    case 11:
                            card = "J";
                    break;
                    case 12:
                            card = "Q";
                    break;
                    case 13:
                            card = "K";
                    break;
                    case 14:
                            card = "A";
                    break;
                    default:
                            card = Integer.toString(i);
                    break;
            }
            
            table.addCell(new Paragraph(card+clubs,black));
            table.addCell(new Paragraph(card+hearts,red));
            table.addCell(new Paragraph(card+diamonds,red));
            table.addCell(new Paragraph(card+spades,black));
        }
       
        document.add(table);
        document.close();
       
    } catch (DocumentException e) {
        e.printStackTrace();
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }
    }
		
}
